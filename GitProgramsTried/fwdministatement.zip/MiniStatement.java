package com.BankSpring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class MiniStatement {

	private int accountNo;
	private String firstName;
	private String lastName;
	private int amount;
	private Date transDate;
	private String transType;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	
	private JdbcTemplate template;
	
	

	
	public List<MiniStatement> getAllEmployeesRowMapper(){  
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com/BankSpring/applicationContext.xml");
		DataSource dataSource= (DriverManagerDataSource)ctx.getBean("dataSource");
		JdbcTemplate jt=new JdbcTemplate(dataSource);
		 return jt.query("select * from Trans",new RowMapper(){  
		    @Override  
		    public MiniStatement mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        MiniStatement e=new MiniStatement();  
		      e.setTransDate(rs.getDate("transdate"));
		      e.setAccountNo(rs.getInt("AccountNo"));
		      e.setAmount(rs.getInt("amount"));  
		      e.setTransType(rs.getString("transType"));
		      return e;  
		    }  
		    });  
		}  
	
}
