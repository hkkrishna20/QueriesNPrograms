package com.BankSpring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class Trans {

	private int accountNo;
	private int transAmount;
	private String transtype;
	private String transDate;
	
	private JdbcTemplate template;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public int getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(int transAmount) {
		this.transAmount = transAmount;
	}

	public String getTranstype() {
		return transtype;
	}

	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	
	public List<Trans> getMiniStatement(int accountNo){
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("com/BankSpring/applicationContext.xml");
		DataSource dataSource= (DriverManagerDataSource)ctx.getBean("dataSource");
		JdbcTemplate jt=new JdbcTemplate(dataSource);
		return jt.query("select * from Trans where AccountNo=?",new Object[]{accountNo},new RowMapper(){  
		    @Override  
		    public Trans mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        Trans e=new Trans();  
		        e.setTransAmount(rs.getInt("TransAmount"));
		        e.setTranstype(rs.getString("TransType"));
		        e.setAccountNo(rs.getInt("accountNo"));
		        e.setTransDate(rs.getString("TransDate"));
		        return e;  
		    }  
		    });  
		}  
	
	

}
