import java.util.Scanner;


public class AddStock {
public static void main(String[] args) {
	  StockInventory objStock=new StockInventory();
	  String sID=  objStock.generateStockID();
	  Scanner scr=new Scanner(System.in);
	  objStock.setStockID(sID);
	  System.out.println("Enter Stock Name"); 
	  objStock.setStockName(scr.nextLine());
	  System.out.println("\nQuantity");
	  objStock.setQuantity(scr.nextInt());
	   System.out.println("\nEnter price");
	   objStock.setPrice(scr.nextInt());
	   System.out.println(objStock.addStocks(objStock));
}
}
