import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class SearchInventoryMain {


public static void main(String[] args) {
	String sIID;
	System.out.println("Enter Stock ID");
Scanner scr=new Scanner(System.in);
sIID=scr.nextLine();
StockInventory objINV=new StockInventory();
ResultSet rs=objINV.searchInventory(sIID);
try {
if(rs.next()){
	System.out.println("Stock ID "+rs.getString("StockID"));
	System.out.println("Stock Name "+rs.getString("StockName"));
	System.out.println("Quantity "+rs.getString("Quantity"));
	System.out.println("Price "+rs.getString("Price"));
	
}
else{
	
	System.out.println("Stock not Found");
}

} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
}

