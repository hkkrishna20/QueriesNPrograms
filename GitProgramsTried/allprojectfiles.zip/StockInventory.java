import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class StockInventory {

	 public String getStockID() {
		return StockID;
	}
	public void setStockID(String stockID) {
		StockID = stockID;
	}
	public String getStockName() {
		return StockName;
	}
	public void setStockName(String stockName) {
		StockName = stockName;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	private  String StockID;
	  private String StockName;
	  public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	private String orderID;
	  private int Quantity;
	  private int Price;
	  private Connection conn;
	  private PreparedStatement pst;
	  public String generateStockID(){
		  
		  conn=ConnectionHelper.getConnection();
		  String cmd="  select CASE WHEN MAX(STOCKID) IS NULL then 'S000'"
		  + "else MAX(StockID) END sid from stock";
		  try {
			pst=conn.prepareStatement(cmd);
			ResultSet rs=pst.executeQuery();
			rs.next();
			
				String stockIID=rs.getString("sid");
				System.out.println(stockIID);
				int accno=Integer.parseInt(stockIID.substring(1));
				if(accno>=0&&accno<10){
					accno++;
					String sID="S00"+accno;
					System.out.println(sID);
				return sID;
				}	
				else if(accno>9&&accno<99){
					String sID="S0"+accno;
						return sID;
				}
				else if(accno>99&&accno<999){
					
					String sID="S"+accno;
					return sID;
				}
				else{
					
					String sID="E100";
					return sID;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return e.getMessage();
		}
		
	  }
public String addStocks(StockInventory obj){

	  conn=ConnectionHelper.getConnection();

	
	 String cmd= " insert into Stock(StockID,StockName,Quantity,Price)"
		+ " values(?,?,?,?)";
	 try {
		pst=conn.prepareStatement(cmd);
		pst.setString(1, obj.getStockID());
		pst.setString(2, obj.getStockName());
		pst.setInt(3, obj.getQuantity());
		pst.setInt(4, getPrice());
		pst.executeUpdate();
		return "Inventory Updated with Insertion";
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return e.getMessage();
	}
	 
}

public ResultSet searchInventory(String StockID){
	
	conn=ConnectionHelper.getConnection();
	try {
		pst=conn.prepareStatement("select * from Stock where StockID=?");
	pst.setString(1, StockID);
	ResultSet rs=pst.executeQuery();
	return rs;
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	return null;
	}
	
}
public String generateOrderID(){
	  
	  conn=ConnectionHelper.getConnection();
	  String cmd="  select CASE WHEN MAX(orderID) IS NULL then 'o000'"
	  + "else MAX(orderID) END oid from Orders";
	  try {
		pst=conn.prepareStatement(cmd);
		ResultSet rs=pst.executeQuery();
		rs.next();
		
			String OrderIID=rs.getString("oid");
			System.out.println(OrderIID);
			int Orderno=Integer.parseInt(OrderIID.substring(1));
			if(Orderno>=0&&Orderno<10){
				Orderno++;
				String oID="o00"+Orderno;
				System.out.println(oID);
			return oID;
			}	
			else if(Orderno>9&&Orderno<99){
				String oID="o0"+Orderno;
					return oID;
			}
			else if(Orderno>99&&Orderno<999){
				
				String oID="o"+Orderno;
				return oID;
			}
			else{
				
				String oID="E100";
				return oID;
			}
	} 
	  catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	return e.getMessage();
	}
	
}
public String addOrder(String StockID,int quantity){

	  conn=ConnectionHelper.getConnection();

	
	 String cmd= " insert into Orders(orderId,StockID,qtyOrdD,billAmount)"
		+ " values(?,?,?,?)";
	 try {
		 
		pst=conn.prepareStatement(cmd);
		StockInventory objj=new StockInventory();
		String newe=objj.generateOrderID();		
		ResultSet rs=objj.searchInventory(StockID);
		if(rs.next()){	
			int quantity1=Integer.parseInt(rs.getString("Quantity"));
			int price=Integer.parseInt(rs.getString("Price"));
			int billAmount1=quantity*price;
			
			if(quantity1-quantity>=0){
		pst.setString(1, newe);
		pst.setString(2,StockID);
		pst.setInt(3, quantity);
		pst.setInt(4, billAmount1);
		pst.executeUpdate();

		 cmd= " update Stock set Quantity=Quantity-quantity where StockID=StockID";
		 pst=conn.prepareStatement(cmd);
		 pst.executeUpdate();
		 cmd=" update TotalBill set billAmount=billAmount+billAmount1";
		return "Order Placed";
		}else{
			
			return "Quantity exceeding the limit ";
		}
			
		}
		else{
			
			return "StockID not Found";
			}

		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return e.getMessage();
	}
	 
}

}
