import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class PurchaseOrder {
public static void main(String[] args) {
		String stockID;
		int quantity;
		System.out.println("Enter Stock ID");
			Scanner scr=new Scanner(System.in);
			stockID=scr.nextLine();
			System.out.println("Enter Quantity");
				quantity=scr.nextInt();
			StockInventory obj=new StockInventory();
			System.out.println(stockID+" "+quantity);
			
			System.out.println(obj.addOrder(stockID,quantity));

	}
}
